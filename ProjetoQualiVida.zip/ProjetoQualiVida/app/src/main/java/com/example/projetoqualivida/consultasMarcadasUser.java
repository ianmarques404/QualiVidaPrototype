package com.example.projetoqualivida;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class consultasMarcadasUser extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultas_marcadas_user);
    }
}