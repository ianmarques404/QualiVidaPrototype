package com.example.projetoqualivida;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class qualiVida extends AppCompatActivity {

    private ImageView config;
    private ImageView perfil;
    private ImageView calendario;
    private ImageView zapi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quali_vida);
        calendario = (ImageView) findViewById(R.id.Calendario);
        calendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirConsultas();
            }
        });

        perfil = (ImageView) findViewById(R.id.Perfil);
        perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirPerfil();
            }
        });

        config = (ImageView) findViewById(R.id.gearIcon);
        config.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirconfig();
            }
        });

        zapi = (ImageView) findViewById(R.id.LogoZapi);{
            zapi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    gotoUrl("https://play.google.com/store/apps/details?id=com.whatsapp&hl=pt_BR&pli=1");

                }
            });
        }

    }

    private void gotoUrl(String s) {

        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }


    public void abrirConsultas(){
        Intent intent = new Intent(this, consultasMarcadasUser.class);
        startActivity(intent);


    }

    public void abrirZapi(){

        Intent intent = new Intent();

    }

    public void abrirPerfil(){

        Intent intent = new Intent(this, PerfilUser.class);
        startActivity(intent);

    }

    public void abrirconfig(){
        Intent intent = new Intent(this, configUser.class);
        startActivity(intent);

    }



}