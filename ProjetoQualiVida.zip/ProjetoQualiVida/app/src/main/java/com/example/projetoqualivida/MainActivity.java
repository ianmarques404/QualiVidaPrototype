package com.example.projetoqualivida;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button cadastrar;

    private Button logar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logar = (Button) findViewById(R.id.entrarLogin);
        logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirMain();
            }
        });
        cadastrar = (Button) findViewById(R.id.cadastroLogin);
        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                redirCadastro();
            }
        });
    }
    public void redirMain(){
        Intent intent = new Intent(this, qualiVida.class);
        startActivity(intent);
    }

    public void redirCadastro(){
        Intent intent = new Intent(this, CadastroActivity.class);
        startActivity(intent);
    }

}